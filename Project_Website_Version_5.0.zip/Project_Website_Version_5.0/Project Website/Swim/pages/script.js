const form = document.getElementById("signup-form");

form.addEventListener("submit", function(event) {
  event.preventDefault();

  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const phone = document.getElementById("phone").value;
  const level = document.getElementById("level").value;
  const submit = document.querySelector('input[name="confirm"]:checked').value;

  const currentTime = new Date().toLocaleTimeString(); // get the current time as a string
  
  const result = `Name: ${name}\nEmail: ${email}\nPhone Number: ${phone}\nSkill Level: ${level}\nWould you like us to send you newsletter?: ${submit}\nCurrent Time: ${currentTime}`; // add the current time to the result string
  
  alert(result);
});
