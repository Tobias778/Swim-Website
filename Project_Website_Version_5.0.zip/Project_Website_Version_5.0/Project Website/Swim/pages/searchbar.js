$(document).ready(function() {
  $('.search-container input').on('input', function() {
    var query = $(this).val();
    if (query.length >= 2) {
      $.get('/search?q=' + query, function(data) {
        if (data.length > 0) {
          var suggestions = '';
          $.each(data, function(i, item) {
            suggestions += '<li>' + item + '</li>';
          });
          $('.search-suggestions').html('<ul>' + suggestions + '</ul>').show();
          $('.search-results').hide();
        } else {
          $('.search-suggestions').hide();
          $('.search-results').html('No results found.').show();
        }
      });
    } else {
      $('.search-suggestions').hide();
      $('.search-results').hide();
    }
  });

  $(document).on('click', '.search-suggestions li', function() {
    var query = $(this).text();
    $('.search-container input').val(query);
    $('.search-suggestions').hide();
    $('.search-results').html('Loading...').show();
    $.get('/search?q=' + query, function(data) {
      var results = '';
      $.each(data, function(i, item) {
        results += '<li>' + item + '</li>';
      });
      $('.search-results').html('<ul>' + results + '</ul>');
    });
  });

  $(document).on('click', function(event) {
    if (!$(event.target).closest('.search-container').length) {
      $('.search-suggestions').hide();
      $('.search-results').hide();
    }
  });
});
